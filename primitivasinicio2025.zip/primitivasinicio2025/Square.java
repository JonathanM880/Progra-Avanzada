package com.progavanzada.primitivasinicio2025;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class Square {
    private final FloatBuffer vertexBuffer; //buffer de memoria que guarda coordenadas de vertices
    private final int mProgram; //combinar vertex shader con fragment shader (para ejecutar)
    private int positionHandle; //pasarle los datos de posición del vértice al shader.
    private int colorHandle; //almacena id del color
    static final int COORDS_PER_VERTEX = 3;

    float color[] = {0.33f,0.6123f,0.033333f,1.0f};

    static float squareCoords[] = {
            -0.75f, 0.8f, 0.0f, //izq. sup //0
            -0.75f, 0.4f, 0.0f, //izq. inf //1
            -0.35f,0.4f,0.0f, //der.inf //2
            -0.35f,0.8f,0.0f //der. sup //3
    };

    private final short drawOrder[] ={
            0,1,2, //triangulo 1
            0,2,3 //triangulo 2
    };
    private final ShortBuffer shortBuffer; //para el arreglo drawOrder

    public Square(){
        // siempre necesarias
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(squareCoords.length*4);
        byteBuffer.order(ByteOrder.nativeOrder()); //sirve para establecer el orden de bytes (endianness) del buffer
        vertexBuffer = byteBuffer.asFloatBuffer(); //convierte a floatBuffer para trabajar con floats en lugar de bytes
        vertexBuffer.put(squareCoords); //Copia los valores del arreglo pointCoord al FloatBuffer
        vertexBuffer.position(0); //para que empiece desde la posicion 0 del arreglo

        //PARA EL SHORTBUFFER -- hacemos lo mismo para cualquier arreglo nuevo que agreguemos
        ByteBuffer sb = ByteBuffer.allocateDirect(drawOrder.length*4);
        sb.order(ByteOrder.nativeOrder()); //sirve para establecer el orden de bytes (endianness) del buffer
        shortBuffer = sb.asShortBuffer(); //convierte a floatBuffer para trabajar con floats en lugar de bytes
        shortBuffer.put(drawOrder); //Copia los valores del arreglo pointCoord al FloatBuffer
        shortBuffer.position(0); //para que empiece desde la posicion 0 del arreglo

        int vertexShader = MyGLRenderer.loadShaders(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShaders(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram(); //crea el programa
        GLES20.glAttachShader(mProgram,vertexShader); //agrega el vertex a la inicicializacion del programa
        GLES20.glAttachShader(mProgram,fragmentShader);
        GLES20.glLinkProgram(mProgram); //para compilar programa

    }

    private final String vertexShaderCode =
            "attribute vec4 vPosition;"+ //es como una variable vec4 es como un tipo de dato y vPosition siempre debe llamarse asi
                    "void main(){"+
                    "gl_Position = vPosition;"+
                    "}"; //ATTRIBUTES

    private final String fragmentShaderCode=
            "precision mediump float;"+
                    "uniform vec4 vColor;"+
                    "void main(){"+
                    "gl_FragColor =vColor; "+
                    "}"; //UNIFORMS

    public void draw(){
        GLES20.glUseProgram(mProgram);
        positionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition"); // identificador de la posicion
        GLES20.glEnableVertexAttribArray(positionHandle);

        GLES20.glVertexAttribPointer(
                positionHandle, COORDS_PER_VERTEX,
                GLES20.GL_FLOAT, false,
                COORDS_PER_VERTEX*4, vertexBuffer
        );
        colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        GLES20.glUniform4fv(
                colorHandle, 1, //numero de vectores que se va a enviar
                color, 0); //donde se empiezan a leer los valores (indice arreglo)

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, //para construir figuras con varios triangulos u otras figuras
                                drawOrder.length, GLES20.GL_UNSIGNED_SHORT,
                                shortBuffer);
        GLES20.glDisableVertexAttribArray(positionHandle); //es como limpiar
    }



}

