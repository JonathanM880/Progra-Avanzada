package com.progavanzada.grupalpiramide;

public class PiramideTriangular {

    // Triángulos que componen el tetraedro (4 caras)
    private final Triangle[] caras;

    public PiramideTriangular() {
        // Crear los triángulos que forman las 4 caras del tetraedro
        caras = new Triangle[4];

        // Crear los triángulos con sus vértices correspondientes y colores
        caras[0] = new Triangle(new float[]{
                0.0f,  0.5f,  0.0f,  // Vértice superior
                -0.5f, -0.5f,  0.5f,  // Vértice inferior izquierdo
                0.5f, -0.5f,  0.5f   // Vértice inferior derecho
        }, new float[]{1.0f, 0.0f, 0.0f, 1f});  // Rojo

        caras[1] = new Triangle(new float[]{
                0.0f,  0.5f,  0.0f,  // Vértice superior
                0.5f, -0.5f,  0.5f,   // Vértice inferior derecho
                0.0f, -0.5f, -0.5f    // Vértice inferior trasero
        }, new float[]{0.0f, 1.0f, 0.0f, 1.0f});  // Verde

        caras[2] = new Triangle(new float[]{
                0.0f,  0.5f,  0.0f,  // Vértice superior
                0.0f, -0.5f, -0.5f,   // Vértice inferior trasero
                -0.5f, -0.5f,  0.5f   // Vértice inferior izquierdo
        }, new float[]{0.0f, 0.0f, 1.0f, 1.0f});  // Azul

        caras[3] = new Triangle(new float[]{
                -0.5f, -0.5f,  0.5f,  // Vértice inferior izquierdo
                0.5f, -0.5f,  0.5f,   // Vértice inferior derecho
                0.0f, -0.5f, -0.5f    // Vértice inferior trasero
        }, new float[]{1.0f, 1.0f, 0.0f, 1.0f});  // Amarillo
    }
    public void draw(float[] mMVPMatrix) {
        for (Triangle cara : caras) {
            cara.draw(mMVPMatrix);  // Enviar la matriz MVP a cada cara del tetraedro
        }
    }
}






