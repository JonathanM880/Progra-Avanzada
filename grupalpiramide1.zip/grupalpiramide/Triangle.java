package com.progavanzada.grupalpiramide;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
public class Triangle {
    private float[] triangleVertices;
    private float[] triangleColor;
    private FloatBuffer vertexBuffer;
    private FloatBuffer colorBuffer;

    // Códigos de los shaders
    private final String vertexShaderCode =
            "attribute vec4 vPosition;" +
                    "uniform mat4 uMVPMatrix;" +
                    "void main() {" +
                    "    gl_Position = uMVPMatrix * vPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "uniform vec4 color;" +
                    "void main() {" +
                    "    gl_FragColor = color;" +
                    "}";

    public Triangle(float[] vertices, float[] color) {
        this.triangleVertices = vertices;
        this.triangleColor = color;

        // Convertir los vértices y colores en buffers
        ByteBuffer vertexByteBuffer = ByteBuffer.allocateDirect(triangleVertices.length * 4);
        vertexByteBuffer.order(ByteOrder.nativeOrder());
        vertexBuffer = vertexByteBuffer.asFloatBuffer();
        vertexBuffer.put(triangleVertices);
        vertexBuffer.position(0);

        ByteBuffer colorByteBuffer = ByteBuffer.allocateDirect(triangleColor.length * 4);
        colorByteBuffer.order(ByteOrder.nativeOrder());
        colorBuffer = colorByteBuffer.asFloatBuffer();
        colorBuffer.put(triangleColor);
        colorBuffer.position(0);
    }


    public void draw(float[] mMVPMatrix) {
        // Cargar los shaders
        int vertexShader = MyGLRenderer.loadShaders(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShaders(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        // Crear el programa y asociar los shaders
        int program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vertexShader);
        GLES20.glAttachShader(program, fragmentShader);
        GLES20.glLinkProgram(program);
        GLES20.glUseProgram(program);

        // Obtener la ubicación de los atributos y uniformes
        int positionHandle = GLES20.glGetAttribLocation(program, "vPosition");
        int colorHandle = GLES20.glGetUniformLocation(program, "color");
        int mvpMatrixHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix");

        // Configurar el atributo de posición
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 12, vertexBuffer);
        GLES20.glEnableVertexAttribArray(positionHandle);

        // Configurar el color del triángulo
        GLES20.glUniform4fv(colorHandle, 1, colorBuffer);

        // Enviar la matriz MVP al shader
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mMVPMatrix, 0);

        // Dibujar el triángulo
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3);

        // Desactivar los atributos
        GLES20.glDisableVertexAttribArray(positionHandle);
        GLES20.glDisableVertexAttribArray(colorHandle);
    }
}
